
          window.__NEXT_REGISTER_PAGE('/_document', function() {
            var comp = module.exports=webpackJsonp([4],[],[360]);
            return { page: comp.default }
          })
        