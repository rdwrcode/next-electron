
          window.__NEXT_REGISTER_PAGE('/start', function() {
            var comp = module.exports=webpackJsonp([2],[],[358]);
            return { page: comp.default }
          })
        