export default () => (
  <span>use next.js in renderer!</span>
)
